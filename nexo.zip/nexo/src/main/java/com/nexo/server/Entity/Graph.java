package com.nexo.server.Entity;

public class Graph {
    private int angleValues;
    private int torqueValues;
    private int timeValues;
    private int points;
    private int angleScale;
    private int torqueScale;
    private int timeScale;
}
