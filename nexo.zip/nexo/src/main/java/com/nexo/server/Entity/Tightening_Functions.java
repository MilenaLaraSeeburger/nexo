package com.nexo.server.Entity;

public class Tightening_Functions {
    private String name;
    private int nom;
    private int act;
}
